document.title = "A new title";
document.getElementById("demo").innerHTML = document.title;