function message() {
    return "test";
  }