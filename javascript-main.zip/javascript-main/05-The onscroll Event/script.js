function myFunction() {
    if (document.documentElement.scrollTop > 350) {
      document.getElementById("myImg").className = "slideUp";
    }
  }